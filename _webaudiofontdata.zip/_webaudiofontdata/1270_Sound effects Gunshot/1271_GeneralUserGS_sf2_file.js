console.log('load _tone_1271_GeneralUserGS_sf2_file');
var _tone_1271_GeneralUserGS_sf2_file={
	zones:[
		{
			midi:127
			,originalPitch:6000
			,keyRangeLow:0
			,keyRangeHigh:127
			,loopStart:6
			,loopEnd:42
			,coarseTune:-30
			,fineTune:0
			,sampleRate:48000
			,ahdsr:true
			,file:'SUQzBAAAAAAAI1RTU0UAAAAPAAADTGF2ZjU3LjcyLjEwMQAAAAAAAAAAAAAA//tUwAAAAAAAAAAAAAAAAAAAAAAAWGluZwAAAA8AAAACAAADwADm5ubm5ubm5ubm5ubm5ubm5ubm5ubm5ubm5ubm5ubm5ubm5ubm5ubm5ubm5ubm5ubm//////////////////////////////////////////////////////////////////8AAAAATGF2YzU3Ljk2AAAAAAAAAAAAAAAAJAaQAAAAAAAAA8BoP29aAAAAAAAAAAAAAAAAAAAA//vExAAACpk1eeCJPqH4qOz48LJ4hmeqd4pvtqyAZmMYx5jyAAAB5AngAl+YxjfHyAAHIHjADMY3mMb9/9CEJ/znP/kIQ7/nIQhCepwMVisEwTBMVkiDLRo0aNGwGKgQB8H34IAgGOJwf78m96FYplAAkIakYpRDeBTE6J0DmHpDlWTmLk5wVacr58+fW/4QhCEP4hCEJfCEIhC/MIQhD+IQhCf4QhEJ/IIQhCviEIQrfMzO1WrVq61p3psdGIkiSJJi7ASgSASACACBEDoinruVr2WXLlz1YNQVBoOw1EoKuU2WDvr/1ExBTUVMQU1FMy45OS41qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sUxNoDwAABpAAAACAAADSAAAAEqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq'
			,anchor:0.00002083
			//_tone.Sine_Triangle_12000H
		}
	]
};
